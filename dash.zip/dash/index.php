<?php
/*******************************************************
 * index.php — Dashboard + ABM (una sola página)
 * BACKEND: MySQL (mysqli) usando config/config.php ($con)
 * UI: Bootstrap + fetch POST (sin GET en URLs)
 *******************************************************/
declare(strict_types=1);
ini_set('display_errors', '1'); error_reporting(E_ALL);
if (session_status() === PHP_SESSION_NONE) { session_start(); }

/* ====== Cargar conexión MySQLi ====== */
require_once __DIR__ . '/config/config.php'; // Debe definir $con instanceof mysqli
if (!isset($con) || !($con instanceof mysqli)) {
  http_response_code(500);
  echo "Falta \$con (mysqli) desde config/config.php"; exit;
}
$con->set_charset('utf8mb4');

/* ====== Helpers ====== */
function csrf_token(): string {
  if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
  return $_SESSION['csrf'];
}
function assert_csrf(): void {
  $token = $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
  if (!hash_equals($_SESSION['csrf'] ?? '', (string)$token)) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'CSRF inválido']); exit;
  }
}
/** Ejecuta consulta simple (sin parámetros) y devuelve array asociativo */
function qall(mysqli $db, string $sql): array {
  $rs = $db->query($sql);
  if (!$rs) throw new RuntimeException($db->error);
  $out = [];
  while ($row = $rs->fetch_assoc()) { $out[] = $row; }
  $rs->free();
  return $out;
}
/** Ejecuta prepared (INSERT/UPDATE/DELETE) */
function qprep(mysqli $db, string $sql, string $types, array $params): mysqli_stmt {
  $st = $db->prepare($sql);
  if (!$st) throw new RuntimeException($db->error);
  if ($types !== '') { $st->bind_param($types, ...$params); }
  if (!$st->execute()) throw new RuntimeException($st->error);
  return $st;
}

/* ====== Bootstrap DB (crea tablas y seeds) ====== */
function bootstrap(mysqli $db): void {
  $ddl = [
    "CREATE TABLE IF NOT EXISTS estados (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nombre VARCHAR(80) NOT NULL UNIQUE,
      color  CHAR(7) NOT NULL DEFAULT '#6c757d'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS clientes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nombre   VARCHAR(120) NOT NULL,
      contacto VARCHAR(160) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS equipos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nombre VARCHAR(120) NOT NULL,
      lider  VARCHAR(120) NULL,
      email  VARCHAR(160) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS proyectos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nombre VARCHAR(160) NOT NULL,
      cliente_id INT NULL,
      estado_id  INT NULL,
      fecha_inicio DATE NULL,
      fecha_fin    DATE NULL,
      avance TINYINT NOT NULL DEFAULT 0,
      CONSTRAINT fk_proy_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL,
      CONSTRAINT fk_proy_estado  FOREIGN KEY (estado_id)  REFERENCES estados(id)  ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS modulos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      proyecto_id INT NOT NULL,
      nombre VARCHAR(160) NOT NULL,
      tipo ENUM('producto','rubro','pedido') NOT NULL,
      equipo_id INT NULL,
      avance TINYINT NOT NULL DEFAULT 0,
      CONSTRAINT fk_mod_proy FOREIGN KEY (proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,
      CONSTRAINT fk_mod_equipo FOREIGN KEY (equipo_id)   REFERENCES equipos(id)   ON DELETE SET NULL,
      INDEX idx_mod_proy (proyecto_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
  ];
  foreach ($ddl as $sql) { if (!$db->query($sql)) throw new RuntimeException($db->error); }

  // Seeds de estados si está vacío
  $cnt = (int)qall($db, "SELECT COUNT(*) c FROM estados")[0]['c'];
  if ($cnt === 0) {
    $db->query("INSERT INTO estados (nombre,color) VALUES
      ('En definición','#6c757d'),
      ('En curso','#0d6efd'),
      ('Bloqueado','#dc3545'),
      ('En pruebas','#fd7e14'),
      ('Cerrado','#198754')");
  }
}
bootstrap($con);

/* ====== API (solo POST, sin GET) ====== */
if (!empty($_POST['ajax'])) {
  header('Content-Type: application/json; charset=utf-8');
  assert_csrf();
  $op   = $_POST['op']  ?? '';
  $mod  = $_POST['mod'] ?? '';
  // data puede venir como JSON string o arreglo
  $data = $_POST['data'] ?? [];
  if (is_string($data)) { $tmp = json_decode($data, true); if (json_last_error() === JSON_ERROR_NONE) $data = $tmp; }

  try {
    switch ("$mod:$op") {
      /* ===== DASHBOARD ===== */
      case 'dashboard:metrics': {
        // avance de proyecto = AVG(modulos.avance) si existen módulos; sino, toma proyectos.avance
        $items = qall($con, "
          SELECT p.id, p.nombre,
                 COALESCE(c.nombre,'—') AS cliente,
                 COALESCE(e.nombre,'—') AS estado,
                 COALESCE(e.color,'#6c757d') AS estado_color,
                 COALESCE( (SELECT ROUND(AVG(m.avance),0) FROM modulos m WHERE m.proyecto_id=p.id), p.avance) AS avance,
                 COALESCE(DATE_FORMAT(p.fecha_inicio,'%Y-%m-%d'),'') AS fecha_inicio,
                 COALESCE(DATE_FORMAT(p.fecha_fin,'%Y-%m-%d'),'') AS fecha_fin
          FROM proyectos p
          LEFT JOIN clientes c ON c.id=p.cliente_id
          LEFT JOIN estados  e ON e.id=p.estado_id
          ORDER BY p.id DESC
        ");
        $resumen = qall($con, "
          SELECT e.nombre AS estado, e.color, COUNT(p.id) AS cantidad
          FROM estados e
          LEFT JOIN proyectos p ON p.estado_id = e.id
          GROUP BY e.id, e.nombre, e.color
          ORDER BY e.nombre
        ");
        echo json_encode(['ok'=>true,'items'=>$items,'resumen'=>$resumen]); break;
      }

      /* ===== ESTADOS ===== */
      case 'estados:list': {
        echo json_encode(['ok'=>true,'items'=>qall($con,"SELECT * FROM estados ORDER BY id DESC")]); break;
      }
      case 'estados:create': {
        $n = trim($data['nombre'] ?? ''); $c = $data['color'] ?? '#6c757d';
        qprep($con, "INSERT INTO estados (nombre,color) VALUES (?,?)", "ss", [$n ?: 'Estado', $c]);
        echo json_encode(['ok'=>true,'id'=>$con->insert_id]); break;
      }
      case 'estados:update': {
        qprep($con, "UPDATE estados SET nombre=?, color=? WHERE id=?", "ssi", [
          $data['nombre']??'', $data['color']??'#6c757d', (int)$data['id']
        ]);
        echo json_encode(['ok'=>true]); break;
      }
      case 'estados:delete': {
        qprep($con, "DELETE FROM estados WHERE id=?", "i", [(int)$data['id']]);
        echo json_encode(['ok'=>true]); break;
      }

      /* ===== CLIENTES ===== */
      case 'clientes:list': {
        echo json_encode(['ok'=>true,'items'=>qall($con,"SELECT * FROM clientes ORDER BY id DESC")]); break;
      }
      case 'clientes:create': {
        qprep($con, "INSERT INTO clientes (nombre,contacto) VALUES (?,?)", "ss", [
          trim($data['nombre']??'Cliente'), ($data['contacto']??null)
        ]);
        echo json_encode(['ok'=>true,'id'=>$con->insert_id]); break;
      }
      case 'clientes:update': {
        qprep($con, "UPDATE clientes SET nombre=?, contacto=? WHERE id=?", "ssi", [
          trim($data['nombre']??''), ($data['contacto']??null), (int)$data['id']
        ]);
        echo json_encode(['ok'=>true]); break;
      }
      case 'clientes:delete': {
        qprep($con, "DELETE FROM clientes WHERE id=?", "i", [(int)$data['id']]);
        echo json_encode(['ok'=>true]); break;
      }

      /* ===== EQUIPOS ===== */
      case 'equipos:list': {
        echo json_encode(['ok'=>true,'items'=>qall($con,"SELECT * FROM equipos ORDER BY id DESC")]); break;
      }
      case 'equipos:create': {
        qprep($con, "INSERT INTO equipos (nombre,lider,email) VALUES (?,?,?)", "sss", [
          trim($data['nombre']??'Equipo'), ($data['lider']??null), ($data['email']??null)
        ]);
        echo json_encode(['ok'=>true,'id'=>$con->insert_id]); break;
      }
      case 'equipos:update': {
        qprep($con, "UPDATE equipos SET nombre=?, lider=?, email=? WHERE id=?", "sssi", [
          trim($data['nombre']??''), ($data['lider']??null), ($data['email']??null), (int)$data['id']
        ]);
        echo json_encode(['ok'=>true]); break;
      }
      case 'equipos:delete': {
        qprep($con, "DELETE FROM equipos WHERE id=?", "i", [(int)$data['id']]);
        echo json_encode(['ok'=>true]); break;
      }

      /* ===== PROYECTOS ===== */
      case 'proyectos:list': {
        echo json_encode(['ok'=>true,'items'=>qall($con,"
          SELECT p.*, c.nombre AS cliente, e.nombre AS estado
          FROM proyectos p
          LEFT JOIN clientes c ON c.id=p.cliente_id
          LEFT JOIN estados  e ON e.id=p.estado_id
          ORDER BY p.id DESC
        ")]); break;
      }
      case 'proyectos:create': {
        $a = max(0,min(100,(int)($data['avance']??0)));
        qprep($con, "INSERT INTO proyectos (nombre,cliente_id,estado_id,fecha_inicio,fecha_fin,avance)
                     VALUES (?,?,?,?,?,?)", "sisssi", [
          trim($data['nombre']??'Proyecto'),
          !empty($data['cliente_id']) ? (int)$data['cliente_id'] : null,
          !empty($data['estado_id'])  ? (int)$data['estado_id']  : null,
          ($data['fecha_inicio']??null) ?: null,
          ($data['fecha_fin']??null)    ?: null,
          $a
        ]);
        echo json_encode(['ok'=>true,'id'=>$con->insert_id]); break;
      }
      case 'proyectos:update': {
        $a = max(0,min(100,(int)($data['avance']??0)));
        qprep($con, "UPDATE proyectos SET nombre=?, cliente_id=?, estado_id=?, fecha_inicio=?, fecha_fin=?, avance=? WHERE id=?",
          "sisssii", [
            trim($data['nombre']??''),
            !empty($data['cliente_id']) ? (int)$data['cliente_id'] : null,
            !empty($data['estado_id'])  ? (int)$data['estado_id']  : null,
            ($data['fecha_inicio']??null) ?: null,
            ($data['fecha_fin']??null)    ?: null,
            $a,
            (int)$data['id']
        ]);
        echo json_encode(['ok'=>true]); break;
      }
      case 'proyectos:delete': {
        qprep($con, "DELETE FROM proyectos WHERE id=?", "i", [(int)$data['id']]);
        echo json_encode(['ok'=>true]); break;
      }

      /* ===== MODULOS ===== */
      case 'modulos:list': {
        echo json_encode(['ok'=>true,'items'=>qall($con,"
          SELECT m.*, p.nombre AS proyecto, e.nombre AS equipo
          FROM modulos m
          LEFT JOIN proyectos p ON p.id=m.proyecto_id
          LEFT JOIN equipos   e ON e.id=m.equipo_id
          ORDER BY m.id DESC
        ")]); break;
      }
      case 'modulos:create': {
        $a = max(0,min(100,(int)($data['avance']??0)));
        qprep($con, "INSERT INTO modulos (proyecto_id,nombre,tipo,equipo_id,avance)
                     VALUES (?,?,?,?,?)", "issii", [
          (int)$data['proyecto_id'],
          trim($data['nombre']??'Módulo'),
          ($data['tipo']??'producto'),
          !empty($data['equipo_id']) ? (int)$data['equipo_id'] : null,
          $a
        ]);
        echo json_encode(['ok'=>true,'id'=>$con->insert_id]); break;
      }
      case 'modulos:update': {
        $a = max(0,min(100,(int)($data['avance']??0)));
        qprep($con, "UPDATE modulos SET proyecto_id=?, nombre=?, tipo=?, equipo_id=?, avance=? WHERE id=?",
          "issiii", [
            (int)$data['proyecto_id'],
            trim($data['nombre']??''),
            ($data['tipo']??'producto'),
            !empty($data['equipo_id']) ? (int)$data['equipo_id'] : null,
            $a,
            (int)$data['id']
        ]);
        echo json_encode(['ok'=>true]); break;
      }
      case 'modulos:delete': {
        qprep($con, "DELETE FROM modulos WHERE id=?", "i", [(int)$data['id']]);
        echo json_encode(['ok'=>true]); break;
      }

      default: echo json_encode(['ok'=>false,'error'=>'Operación desconocida']); break;
    }
  } catch (Throwable $ex) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>$ex->getMessage()]);
  }
  exit;
}

/* ====== HTML + JS (UI una sola página) ====== */
$csrf = csrf_token();
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Dashboard Proyectos — ABM Único (MySQL)</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#f6f7fb; }
    .sidebar { width: 280px; }
    .chip { display:inline-block; padding:.15rem .5rem; border-radius:999px; font-size:.75rem; color:#fff; }
    .progress-sm { height: .75rem; }
  </style>
</head>
<body>
  <main class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar bg-white border-end min-vh-100 p-3">
      <h5 class="mb-3">OLSoft-Devs</h5>
      <form id="menuForm" method="post" class="d-grid gap-2">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
        <button class="btn btn-outline-primary" data-mod="dashboard">📊 Dashboard</button>
        <button class="btn btn-outline-secondary" data-mod="proyectos">🧩 Proyectos</button>
        <button class="btn btn-outline-secondary" data-mod="modulos">🧱 Módulos</button>
        <button class="btn btn-outline-secondary" data-mod="clientes">👤 Clientes</button>
        <button class="btn btn-outline-secondary" data-mod="equipos">👥 Equipos</button>
        <button class="btn btn-outline-secondary" data-mod="estados">🏷️ Estados</button>
      </form>
      <hr>
      <div class="small text-muted">
        * version 1.02
      </div>
    </nav>

    <!-- Content -->
    <section class="flex-fill p-4">
      <div id="app"></div>
    </section>
  </main>

  <!-- Templates -->
  <template id="tpl-dashboard">
    <div class="d-flex align-items-center justify-content-between mb-3">
      <h3 class="m-0">📊 Dashboard</h3>
      <button class="btn btn-sm btn-outline-primary" data-reload>Actualizar</button>
    </div>
    <div class="row" id="cardsEstado"></div>
    <hr class="my-4">
    <div class="row row-cols-1 row-cols-lg-2 g-3" id="cardsProyectos"></div>
  </template>

  <template id="tpl-table">
    <div class="d-flex align-items-center justify-content-between mb-3">
      <h3 class="m-0" data-title></h3>
      <div>
        <button class="btn btn-primary btn-sm" data-new>Nuevo</button>
        <button class="btn btn-outline-secondary btn-sm ms-2" data-reload>Actualizar</button>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead><tr data-head></tr></thead>
        <tbody data-body></tbody>
      </table>
    </div>
  </template>

  <!-- Modal -->
  <div class="modal fade" id="modalForm" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">
        <form id="formEntity" method="post">
          <div class="modal-header">
            <h5 class="modal-title">Formulario</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body" id="modalBody"></div>
          <div class="modal-footer">
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary">Guardar</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
  const CSRF = <?= json_encode($csrf) ?>;
  const $app = document.querySelector('#app');
  const modal = new bootstrap.Modal('#modalForm');
  const $modalBody = document.querySelector('#modalBody');
  const $formEntity = document.querySelector('#formEntity');

  async function api(mod, op, data={}) {
    const fd = new FormData();
    fd.append('ajax','1');
    fd.append('csrf', CSRF);
    fd.append('mod',  mod);
    fd.append('op',   op);
    fd.append('data', JSON.stringify(data));
    const res = await fetch('', { method:'POST', body: fd });
    return await res.json();
  }

  // Navegación por POST (sin GET)
  document.querySelector('#menuForm').addEventListener('click', (e)=>{
    if (e.target.matches('button[data-mod]')) {
      e.preventDefault();
      loadView(e.target.getAttribute('data-mod'));
    }
  });

  /* ---------- Dashboard ---------- */
  async function viewDashboard() {
    const tpl = document.querySelector('#tpl-dashboard').content.cloneNode(true);
    const $reload = tpl.querySelector('[data-reload]');
    const $cardsEstado = tpl.querySelector('#cardsEstado');
    const $cardsProyectos = tpl.querySelector('#cardsProyectos');

    async function refresh() {
      const r = await api('dashboard','metrics');
      if (!r.ok) { alert(r.error||'Error'); return; }

      $cardsEstado.innerHTML = '';
      r.resumen.forEach(x=>{
        const col = document.createElement('div');
        col.className='col-6 col-md-3 mb-3';
        col.innerHTML = `
          <div class="card shadow-sm">
            <div class="card-body d-flex justify-content-between">
              <strong>${x.estado}</strong>
              <span class="chip" style="background:${x.color}">${x.cantidad}</span>
            </div>
          </div>`;
        $cardsEstado.appendChild(col);
      });

      $cardsProyectos.innerHTML = '';
      r.items.forEach(p=>{
        const col = document.createElement('div');
        col.className='col';
        const color = p.estado_color || '#6c757d';
        col.innerHTML = `
          <div class="card shadow-sm h-100">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start">
                <div>
                  <h5 class="card-title mb-1">${p.nombre}</h5>
                  <div class="text-muted small">Cliente: ${p.cliente || '—'}</div>
                </div>
                <span class="chip" style="background:${color}">${p.estado || '—'}</span>
              </div>
              <div class="mt-3">
                <div class="d-flex justify-content-between">
                  <small class="text-muted">Avance</small>
                  <small><strong>${p.avance}%</strong></small>
                </div>
                <div class="progress progress-sm">
                  <div class="progress-bar" role="progressbar" style="width:${p.avance}%"></div>
                </div>
              </div>
              <div class="mt-3 small text-muted">
                Inicio: ${p.fecha_inicio||'—'} &nbsp;|&nbsp; Fin: ${p.fecha_fin||'—'}
              </div>
            </div>
          </div>`;
        $cardsProyectos.appendChild(col);
      });
    }

    $reload.addEventListener('click', refresh);
    await refresh();
    $app.innerHTML = ''; $app.appendChild(tpl);
  }

  /* ---------- Tabla genérica ---------- */
async function viewTable(title, columns, fetchList, buildForm, saveHandler, deleteHandler) {
  const tpl = document.querySelector('#tpl-table').content.cloneNode(true);
  tpl.querySelector('[data-title]').textContent = title;
  const $head = tpl.querySelector('[data-head]');
  const $body = tpl.querySelector('[data-body]');
  tpl.querySelector('[data-reload]').addEventListener('click', refresh);
  tpl.querySelector('[data-new]').addEventListener('click', ()=>openForm({}));

  // Header
  $head.innerHTML = columns.map(c=>`<th>${c.label}</th>`).join('') + '<th class="text-end">Acciones</th>';

  async function refresh() {
    const rows = await fetchList();
    $body.innerHTML = '';
    rows.forEach(row=>{
      const tr = document.createElement('tr');
      tr.innerHTML = columns.map(c=>`<td>${(row[c.key]??'').toString()}</td>`).join('') + `
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary me-2" data-edit>Editar</button>
          <button class="btn btn-sm btn-outline-danger" data-del>Eliminar</button>
        </td>`;
      tr.querySelector('[data-edit]').addEventListener('click', ()=>openForm(row));
      tr.querySelector('[data-del]').addEventListener('click', async ()=>{
        if (!confirm('¿Eliminar registro?')) return;
        const ok = await deleteHandler(row);
        if (ok) refresh();
      });
      $body.appendChild(tr);
    });
  }

  async function openForm(row) {
    // Aseguramos que tenemos el builder correcto
    if (typeof buildForm !== 'function') {
      console.error('buildForm no es una función. Revisá la firma de viewTable(...) y las llamadas.');
      alert('Error interno: buildForm no definido'); 
      return;
    }

    $modalBody.innerHTML = '';
    const formContent = buildForm(row);    // <- antes decía formBuilder(row) (causaba el error)
    $modalBody.appendChild(formContent);

    // Importante: la FormData se toma del <form id="formEntity"> real
    $formEntity.onsubmit = async (e)=>{
      e.preventDefault();
      const data = Object.fromEntries(new FormData($formEntity));
      const ok = await saveHandler(row, data);
      if (ok) { modal.hide(); refresh(); }
    };

    modal.show();
  }

  await refresh();
  $app.innerHTML = '';
  $app.appendChild(tpl);
}


  /* ---------- Vistas ABM ---------- */
  async function viewEstados() {
    await viewTable(
      'Estados',
      [{key:'id',label:'ID'},{key:'nombre',label:'Nombre'},{key:'color',label:'Color'}],
      async ()=> (await api('estados','list')).items,
      (row)=>{
        const wrap=document.createElement('div');
        wrap.innerHTML=`
          <input type="hidden" name="id" value="${row.id||''}">
          <div class="mb-3"><label class="form-label">Nombre</label>
            <input class="form-control" name="nombre" value="${row.nombre||''}" required></div>
          <div class="mb-3"><label class="form-label">Color</label>
            <input class="form-control" name="color" type="color" value="${row.color||'#6c757d'}"></div>`;
        return wrap;
      },
      async (row,data)=> row.id ? (await api('estados','update',data)).ok
                                : (await api('estados','create',data)).ok,
      async (row)=> (await api('estados','delete',{id:row.id})).ok
    );
  }

  async function viewClientes() {
    await viewTable(
      'Clientes',
      [{key:'id',label:'ID'},{key:'nombre',label:'Nombre'},{key:'contacto',label:'Contacto'}],
      async ()=> (await api('clientes','list')).items,
      (row)=>{
        const wrap=document.createElement('div');
        wrap.innerHTML=`
          <input type="hidden" name="id" value="${row.id||''}">
          <div class="mb-3"><label class="form-label">Nombre</label>
            <input class="form-control" name="nombre" value="${row.nombre||''}" required></div>
          <div class="mb-3"><label class="form-label">Contacto</label>
            <input class="form-control" name="contacto" value="${row.contacto||''}"></div>`;
        return wrap;
      },
      async (row,data)=> row.id ? (await api('clientes','update',data)).ok
                                : (await api('clientes','create',data)).ok,
      async (row)=> (await api('clientes','delete',{id:row.id})).ok
    );
  }

  async function viewEquipos() {
    await viewTable(
      'Equipos',
      [{key:'id',label:'ID'},{key:'nombre',label:'Nombre'},{key:'lider',label:'Líder'},{key:'email',label:'Email'}],
      async ()=> (await api('equipos','list')).items,
      (row)=>{
        const wrap=document.createElement('div');
        wrap.innerHTML=`
          <input type="hidden" name="id" value="${row.id||''}">
          <div class="mb-3"><label class="form-label">Nombre</label>
            <input class="form-control" name="nombre" value="${row.nombre||''}" required></div>
          <div class="mb-3"><label class="form-label">Líder</label>
            <input class="form-control" name="lider" value="${row.lider||''}"></div>
          <div class="mb-3"><label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" value="${row.email||''}"></div>`;
        return wrap;
      },
      async (row,data)=> row.id ? (await api('equipos','update',data)).ok
                                : (await api('equipos','create',data)).ok,
      async (row)=> (await api('equipos','delete',{id:row.id})).ok
    );
  }

  async function viewProyectos() {
    const [clientes, estados] = await Promise.all([api('clientes','list'), api('estados','list')]);
    await viewTable(
      'Proyectos',
      [
        {key:'id',label:'ID'},
        {key:'nombre',label:'Nombre'},
        {key:'cliente',label:'Cliente'},
        {key:'estado',label:'Estado'},
        {key:'fecha_inicio',label:'Inicio'},
        {key:'fecha_fin',label:'Fin'},
        {key:'avance',label:'Avance (%)'}
      ],
      async ()=> (await api('proyectos','list')).items,
      (row)=>{
        const wrap=document.createElement('div');
        wrap.innerHTML=`
          <input type="hidden" name="id" value="${row.id||''}">
          <div class="mb-3"><label class="form-label">Nombre</label>
            <input class="form-control" name="nombre" value="${row.nombre||''}" required></div>
          <div class="mb-3"><label class="form-label">Cliente</label>
            <select class="form-select" name="cliente_id">
              <option value="">—</option>
              ${(clientes.items||[]).map(c=>`<option value="${c.id}" ${c.id==row.cliente_id?'selected':''}>${c.nombre}</option>`).join('')}
            </select>
          </div>
          <div class="mb-3"><label class="form-label">Estado</label>
            <select class="form-select" name="estado_id">
              <option value="">—</option>
              ${(estados.items||[]).map(s=>`<option value="${s.id}" ${s.id==row.estado_id?'selected':''}>${s.nombre}</option>`).join('')}
            </select>
          </div>
          <div class="row">
            <div class="col-md-6 mb-3"><label class="form-label">Fecha inicio</label>
              <input class="form-control" type="date" name="fecha_inicio" value="${row.fecha_inicio||''}"></div>
            <div class="col-md-6 mb-3"><label class="form-label">Fecha fin</label>
              <input class="form-control" type="date" name="fecha_fin" value="${row.fecha_fin||''}"></div>
          </div>
          <div class="mb-3">
            <label class="form-label">Avance (si no hay módulos)</label>
            <input class="form-range" type="range" min="0" max="100" name="avance" value="${row.avance||0}"
              oninput="this.nextElementSibling.value=this.value"><output>${row.avance||0}</output>%
          </div>`;
        return wrap;
      },
      async (row,data)=> row.id ? (await api('proyectos','update',data)).ok
                                : (await api('proyectos','create',data)).ok,
      async (row)=> (await api('proyectos','delete',{id:row.id})).ok
    );
  }

  async function viewModulos() {
    const [proyectos, equipos] = await Promise.all([api('proyectos','list'), api('equipos','list')]);
    await viewTable(
      'Módulos',
      [{key:'id',label:'ID'},{key:'proyecto',label:'Proyecto'},{key:'nombre',label:'Nombre'},{key:'tipo',label:'Tipo'},{key:'equipo',label:'Equipo'},{key:'avance',label:'Avance (%)'}],
      async ()=> (await api('modulos','list')).items,
      (row)=>{
        const wrap=document.createElement('div');
        wrap.innerHTML=`
          <input type="hidden" name="id" value="${row.id||''}">
          <div class="mb-3"><label class="form-label">Proyecto</label>
            <select class="form-select" name="proyecto_id" required>
              ${(proyectos.items||[]).map(p=>`<option value="${p.id}" ${p.id==row.proyecto_id?'selected':''}>${p.nombre}</option>`).join('')}
            </select>
          </div>
          <div class="mb-3"><label class="form-label">Nombre</label>
            <input class="form-control" name="nombre" value="${row.nombre||''}" required></div>
          <div class="mb-3"><label class="form-label">Tipo</label>
            <select class="form-select" name="tipo">
              ${['producto','rubro','pedido'].map(t=>`<option value="${t}" ${t==row.tipo?'selected':''}>${t}</option>`).join('')}
            </select>
          </div>
          <div class="mb-3"><label class="form-label">Equipo</label>
            <select class="form-select" name="equipo_id">
              <option value="">—</option>
              ${(equipos.items||[]).map(eq=>`<option value="${eq.id}" ${eq.id==row.equipo_id?'selected':''}>${eq.nombre}</option>`).join('')}
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Avance</label>
            <input class="form-range" type="range" min="0" max="100" name="avance" value="${row.avance||0}"
              oninput="this.nextElementSibling.value=this.value"><output>${row.avance||0}</output>%
          </div>`;
        return wrap;
      },
      async (row,data)=> row.id ? (await api('modulos','update',data)).ok
                                : (await api('modulos','create',data)).ok,
      async (row)=> (await api('modulos','delete',{id:row.id})).ok
    );
  }

  /* ---------- Router ---------- */
  async function loadView(mod) {
    switch (mod) {
      case 'dashboard': return viewDashboard();
      case 'proyectos': return viewProyectos();
      case 'modulos':   return viewModulos();
      case 'clientes':  return viewClientes();
      case 'equipos':   return viewEquipos();
      case 'estados':   return viewEstados();
      default:          return viewDashboard();
    }
  }
  // Vista inicial
  loadView('dashboard');
  </script>
</body>
</html>
