<?php      

		//define("URI","http://www.sd-1404648-h00017.ferozo.net"); 
        define("PATH","");      

        $bd_host     = "localhost";
        $bd_usuario  = "u8065_db2";
        $bd_password = "Rd#XABn3d47";
        $bd_base     = "u8065_drd";    
		$con     = mysqli_connect($bd_host, $bd_usuario, $bd_password,$bd_base); 
       // mysql_select_db($bd_base, $con);

		?>